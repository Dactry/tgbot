from telegram import Update
from telegram.ext import ContextTypes
from booking import load_data
from datetime import datetime
from utils import format_date_label

async def all_bookings_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if user_id != context.bot_data.get("ADMIN_ID") and user_id != update.effective_chat.id:
        await update.message.reply_text("⛔️ У вас немає прав для цієї команди.")
        return

    data = load_data()
    if not data:
        await update.message.reply_text("Наразі немає жодного активного бронювання.")
        return

    message_lines = []
    for date_str in sorted(data.keys()):
        slots = data[date_str]
        if not slots:
            continue

        date_obj = datetime.strptime(date_str, "%Y-%m-%d")
        label = format_date_label(date_obj)
        message_lines.append(f"📅 {label}:")

        user_names = {}

        for time_str, booking in slots.items():
            # Витягуємо user_id та імʼя
            if isinstance(booking, dict):
                user_id = booking.get("id")
                first_name = booking.get("first_name", "Користувач")
                username = booking.get("username")
            else:
                user_id = booking
                first_name = "Користувач"
                username = None

            if user_id not in user_names:
                if username:
                    user_names[user_id] = f"{first_name} (@{username})"
                else:
                    user_names[user_id] = first_name

            user_display = user_names[user_id]
            message_lines.append(f"• {time_str} — {user_display}")

    final_message = "\n".join(message_lines)
    await update.message.reply_text(final_message or "Наразі немає активних бронювань.")
