from telegram import Update, BotCommand, BotCommandScopeDefault, BotCommandScopeChat
from telegram.ext import ContextTypes
from config import ADMIN_CHAT_ID

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Я поки що нічого не вмію, але можу навчитися 🙂")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "👋 Привіт! Я бот для бронювання занять.\n\n"
        "Ось що я вмію:\n"
        "• /book — забронювати заняття\n"
    )
    await update.message.reply_text(text)

async def set_bot_commands(app):
    user_commands = [
        BotCommand("start", "Запуск бота"),
        BotCommand("book", "Забронювати заняття"),
        BotCommand("mybookings", "Мої бронювання"),
        BotCommand("cancel", "Скасування бронювання"),
    ]
    await app.bot.set_my_commands(user_commands, scope=BotCommandScopeDefault())

    admin_commands = user_commands + [
        BotCommand("adminbookings", "Переглянути всі бронювання"),
    ]
    await app.bot.set_my_commands(admin_commands, scope=BotCommandScopeChat(chat_id=ADMIN_CHAT_ID))
