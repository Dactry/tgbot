from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes
from booking import cancel_slot, load_data
from datetime import datetime
from config import ADMIN_CHAT_ID
from utils import format_date_label


async def start_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    data = load_data()
    keyboard = []

    for date_str, slots in data.items():
        try:
            date_object = datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            continue

        if user_id == ADMIN_CHAT_ID or any(str(user_id) == str(slot.get("id", slot)) for slot in slots.values()):
            label = format_date_label(date_object)
            keyboard.append([InlineKeyboardButton(label, callback_data=f"cancel_date_{date_str}")])

    if keyboard:
        await update.message.reply_text("Оберіть дату для скасування:", reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        await update.message.reply_text("У вас немає активних бронювань для скасування 😌")


async def handle_cancel_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    callback_data = query.data
    user_id = update.effective_user.id

    if callback_data.startswith("cancel_date_"):
        selected_date = callback_data.replace("cancel_date_", "")
        context.user_data['cancel_date'] = selected_date
        context.user_data['cancel_times'] = []

        day_data = load_data().get(selected_date, {})
        user_times = list(day_data.keys()) if user_id == ADMIN_CHAT_ID else [
            time for time, info in day_data.items()
            if str(info.get("id", info)) == str(user_id)
        ]

        if user_times:
            await send_cancel_time_selection(query, selected_date, user_times, [])
        else:
            await query.edit_message_text("У вас немає бронювань на цю дату.")

    elif callback_data.startswith("cancel_time_"):
        selected_time = callback_data.replace("cancel_time_", "")
        selected_times = context.user_data.get("cancel_times", [])

        if selected_time in selected_times:
            selected_times.remove(selected_time)
        else:
            selected_times.append(selected_time)

        context.user_data['cancel_times'] = selected_times
        selected_date = context.user_data.get("cancel_date")
        day_data = load_data().get(selected_date, {})
        user_times = list(day_data.keys()) if user_id == ADMIN_CHAT_ID else [
            time for time, info in day_data.items()
            if str(info.get("id", info)) == str(user_id)
        ]

        await send_cancel_time_selection(query, selected_date, user_times, selected_times)

    elif callback_data == "confirm_cancel":
        selected_date = context.user_data.get("cancel_date")
        selected_times = context.user_data.get("cancel_times", [])
        confirmed = []

        cancellations = []
        for time in selected_times:
            day_data = load_data().get(selected_date, {})
            booking = day_data.get(time)
            booked_user_id = booking.get("id") if isinstance(booking, dict) else booking
            first_name = booking.get("first_name", "Користувач") if isinstance(booking, dict) else "Користувач"
            username = booking.get("username") if isinstance(booking, dict) else None

            if await cancel_slot(selected_date, time, user_id, context=context, is_admin=(user_id == ADMIN_CHAT_ID)):
                confirmed.append(time)
                cancellations.append({
                    "time": time,
                    "id": booked_user_id,
                    "first_name": first_name,
                    "username": username
                })

        if confirmed:
            date_obj = datetime.strptime(selected_date, "%Y-%m-%d")
            lines = []
            for entry in cancellations:
                user_display = entry["first_name"]
                if entry["username"]:
                    user_display += f" (@{entry['username']})"
                lines.append(f"👤 Заняття у {user_display} було скасовано\n🕒 {entry['time']}")

            await query.edit_message_text(
                f"❌ Скасовано бронювання на {format_date_label(date_obj)}: {', '.join(confirmed)}"
            )

            await context.bot.send_message(
                chat_id=ADMIN_CHAT_ID,
                text=f"🗓 {format_date_label(date_obj)}\n" + "\n\n".join(lines)
            )
        else:
            await query.edit_message_text("Слоти вже скасовані або не належать вам.")


async def send_cancel_time_selection(query, selected_date, user_times, selected_times):
    from config import ADMIN_CHAT_ID
    user_id = query.from_user.id
    buttons = []
    day_data = load_data().get(selected_date, {})

    for time_str in user_times:
        if user_id == ADMIN_CHAT_ID:
            booking = day_data.get(time_str)
            if isinstance(booking, dict):
                username = booking.get("username")
                first_name = booking.get("first_name", "Користувач")
                user_label = f"{first_name} (@{username})" if username else first_name
            else:
                user_label = "Користувач"
            time_label = f"{time_str} — {user_label}"
        else:
            time_label = time_str

        label = f"❌ {time_label}" if time_str in selected_times else time_label
        buttons.append([InlineKeyboardButton(label, callback_data=f"cancel_time_{time_str}")])

    if buttons:
        buttons.append([InlineKeyboardButton("🔓 Підтвердити скасування", callback_data="confirm_cancel")])
        date_obj = datetime.strptime(selected_date, "%Y-%m-%d")
        await query.edit_message_text(
            f"Оберіть слоти для скасування на {format_date_label(date_obj)}:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
    else:
        await query.edit_message_text("Немає доступних слотів для скасування.")

async def notify_user_of_cancellation(context: ContextTypes.DEFAULT_TYPE, user_id: int, date: str, time: str):
    try:
        text = (
            f"❌ Ваше бронювання на {date} о {time} було скасоване адміністратором.\n"
            "Якщо ви вважаєте це помилкою — зверніться до адміністрації."
        )
        await context.bot.send_message(chat_id=user_id, text=text)
    except Exception as e:
        print(f"Не вдалося надіслати повідомлення користувачу {user_id}: {e}")
