from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes
from datetime import datetime, timedelta
from booking import is_slot_available, book_slot, load_data
from constants import AVAILABLE_TIMES
from utils import format_date_label
from config import ADMIN_CHAT_ID

async def start_booking(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = []
    current_day = datetime.now()
    booking_data = load_data()

    for i in range(7):
        booking_date = current_day + timedelta(days=i)
        booking_date_str = booking_date.strftime('%Y-%m-%d')
        booked_timeslots = booking_data.get(booking_date_str, {})

        available_timeslots = [time for time in AVAILABLE_TIMES if time not in booked_timeslots]

        if available_timeslots:
            label = format_date_label(booking_date)
            button = InlineKeyboardButton(label, callback_data=f"date_{booking_date_str}")
            keyboard.append([button])

    if keyboard:
        await update.message.reply_text("Оберіть дату:", reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        await update.message.reply_text("На жаль, немає вільних дат для бронювання 😔")

async def handle_slot_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    callback_data = query.data

    if callback_data.startswith("date_"):
        selected_date = callback_data[5:]
        context.user_data['booking_date'] = selected_date
        context.user_data['booking_times'] = []
        await send_time_selection(query, selected_date, [])

    elif callback_data.startswith("time_"):
        selected_time = callback_data[5:]
        selected_date = context.user_data.get("booking_date")
        selected_times = context.user_data.get("booking_times", [])

        if selected_time in selected_times:
            selected_times.remove(selected_time)
        else:
            if is_slot_available(selected_date, selected_time):
                selected_times.append(selected_time)

        context.user_data['booking_times'] = selected_times
        await send_time_selection(query, selected_date, selected_times)

    elif callback_data == "confirm_booking":
        selected_date = context.user_data.get("booking_date")
        selected_times = context.user_data.get("booking_times", [])
        user = update.effective_user

        if not selected_times:
            await query.answer("Оберіть хоча б один час!", show_alert=True)
            return

        confirmed_times = []
        now = datetime.now()

        for selected_time in selected_times:
            if selected_date == now.strftime("%Y-%m-%d"):
                hour, minute = map(int, selected_time.split(":"))
                time_object = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
                if time_object < now:
                    continue

            if is_slot_available(selected_date, selected_time):
                book_slot(selected_date, selected_time, user)
                confirmed_times.append(selected_time)

        if confirmed_times:

            confirmed_times_sorted = sorted(confirmed_times, key=lambda t: datetime.strptime(t, "%H:%M"))
            confirmed_string = ", ".join(confirmed_times_sorted)

            date_obj = datetime.strptime(selected_date, "%Y-%m-%d")
            await query.edit_message_text(f"✅ Заброньовано: {format_date_label(date_obj)} о {confirmed_string}")

            await context.bot.send_message(
                chat_id=ADMIN_CHAT_ID,
                text=(
                    f"📢 Нова бронь:\n"
                    f"👤 {user.first_name} (@{user.username})\n"
                    f"🗓 {format_date_label(date_obj)}\n"
                    f"🕒 {confirmed_string}"
                )
            )
        else:
            await query.edit_message_text("❌ Усі вибрані слоти вже зайняті або в минулому.")

async def send_time_selection(query, selected_date, selected_times):
    buttons = []
    current_datetime = datetime.now()
    is_today = selected_date == current_datetime.strftime('%Y-%m-%d')

    for time_str in AVAILABLE_TIMES:
        if is_today:
            hour, minute = map(int, time_str.split(":"))
            time_object = current_datetime.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if time_object < current_datetime and time_str not in selected_times:
                continue

        if not is_slot_available(selected_date, time_str) and time_str not in selected_times:
            continue

        label = f"✅ {time_str}" if time_str in selected_times else time_str
        buttons.append([InlineKeyboardButton(label, callback_data=f"time_{time_str}")])

    if buttons:
        buttons.append([InlineKeyboardButton("🔒 Підтвердити", callback_data="confirm_booking")])
        date_obj = datetime.strptime(selected_date, "%Y-%m-%d")
        await query.edit_message_text(
            f"Оберіть часові слоти на {format_date_label(date_obj)}:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
    else:
        await query.edit_message_text("❌ Немає доступних слотів.")

async def show_user_bookings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    data = load_data()

    bookings = []

    for date_str, slots in data.items():
        user_slots = [
            time for time, info in slots.items()
            if (isinstance(info, dict) and str(info.get("id")) == str(user_id)) or str(info) == str(user_id)
        ]
        if user_slots:
            label = format_date_label(datetime.strptime(date_str, "%Y-%m-%d"))
            time_str = ', '.join(sorted(user_slots))
            bookings.append(f"📅 {label}: {time_str}")

    if bookings:
        await update.message.reply_text("Ваші активні бронювання:\n\n" + "\n".join(bookings))
    else:
        await update.message.reply_text("У вас немає активних бронювань 😌")
