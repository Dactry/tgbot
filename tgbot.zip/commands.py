from handlers.base import start, help_command
from handlers.booking import start_booking
from handlers.cancel import start_cancel
from handlers.admin import all_bookings_admin

command_list = [
    ("start", start, "Запуск бота"),
    ("help", help_command, "Список команд"),
    ("book", start_booking, "Забронювати заняття"),
    ("cancel", start_cancel, "Скасувати бронювання"), 
    ("adminbookings", all_bookings_admin, "Переглянути всі бронювання (адміну)")
]
