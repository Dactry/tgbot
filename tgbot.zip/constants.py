AVAILABLE_TIMES = [
    f"{h:02d}:00" for h in range(9, 19) 
]
