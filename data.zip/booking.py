from collections import OrderedDict
import json

DATA_FILE = "data.json"

def load_data():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


from datetime import datetime

def save_data(data):
    # Сортуємо години за часом
    sorted_data = {}
    for date, slots in sorted(data.items()):
        sorted_slots = dict(sorted(
            slots.items(),
            key=lambda x: datetime.strptime(x[0], "%H:%M")
        ))
        sorted_data[date] = sorted_slots

    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(sorted_data, f, ensure_ascii=False, indent=2)

def is_slot_available(date, time):
    data = load_data()
    return time not in data.get(date, {})

def book_slot(date, time, user_data):
    data = load_data()
    if date not in data:
        data[date] = {}
    if time in data[date]:
        return False  # слот вже зайнятий

    data[date][time] = {
        "id": user_data["id"],
        "first_name": user_data["first_name"],
        "username": user_data["username"]
    }
    save_data(data)
    return True


async def cancel_slot(date: str, time: str, user_id: int = None, context=None, is_admin: bool = False) -> bool:
    data = load_data()
    if date in data and time in data[date]:
        booking = data[date][time]
        booked_user_id = booking["id"] if isinstance(booking, dict) else booking

        if booked_user_id == user_id or is_admin:
            del data[date][time]
            if not data[date]:
                del data[date]
            save_data(data)

            # Надсилання повідомлення користувачу
            if is_admin and context:
                try:
                    await context.bot.send_message(
                        chat_id=booked_user_id,
                        text=f"⚠️ Ваше бронювання на {date} о {time} було скасовано адміністратором."
                    )
                except Exception as e:
                    print(f"Не вдалося надіслати повідомлення користувачу: {e}")
            return True
    return False
