from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler
from config import BOT_TOKEN
from handlers.base import start, help_command
from handlers.booking import start_booking, handle_slot_selection, show_user_bookings
from handlers.cancel import start_cancel, handle_cancel_selection
from handlers.admin import all_bookings_admin, user_bookings_list, show_all_user_bookings

async def post_startup(app):
    await app.bot.delete_webhook(drop_pending_updates=True)
    print("🔄 Webhook очищено, бот запущений.")

app = (
    ApplicationBuilder()
    .token(BOT_TOKEN)
    .post_init(post_startup)
    .build()
)

# Додаємо всі команди
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("help", help_command))
app.add_handler(CommandHandler("book", start_booking))
app.add_handler(CommandHandler("cancel", start_cancel))
app.add_handler(CommandHandler("mybookings", show_user_bookings))
app.add_handler(CommandHandler("adminbookings", all_bookings_admin))
app.add_handler(CommandHandler("user_bookings", user_bookings_list))

app.add_handler(CallbackQueryHandler(show_all_user_bookings, pattern=r"^user_bookings_\d+$"))

# Обробка кнопок бронювання
app.add_handler(CallbackQueryHandler(handle_slot_selection, pattern="^(date_|time_|confirm_booking)"))

# Обробка кнопок скасування
app.add_handler(CallbackQueryHandler(handle_cancel_selection, pattern="^(cancel_date_|cancel_time_|confirm_cancel)"))

app.run_polling()
