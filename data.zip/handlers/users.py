import json
import os

USERS_FILE = "users.json"

def load_users():
    if not os.path.exists(USERS_FILE):
        return {}
    with open(USERS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_users(data):
    with open(USERS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def add_user_if_not_exists(user_id: int, first_name: str, username: str):
    users = load_users()
    user_id_str = str(user_id)

    if user_id_str not in users:
        users[user_id_str] = {
            "first_name": first_name,
            "username": username
        }
        save_users(users)
