from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes
from booking import load_data
from datetime import datetime
from utils import format_date_label


async def all_bookings_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if user_id != context.bot_data.get("ADMIN_ID") and user_id != update.effective_chat.id:
        await update.message.reply_text("⛔️ У вас немає прав для цієї команди.")
        return

    data = load_data()
    if not data:
        await update.message.reply_text("Наразі немає жодного активного бронювання.")
        return

    message_lines = []
    for date_str in sorted(data.keys()):
        slots = data[date_str]
        if not slots:
            continue

        date_obj = datetime.strptime(date_str, "%Y-%m-%d")
        label = format_date_label(date_obj)
        message_lines.append(f"📅 {label}:")

        user_names = {}

        for time_str, booking in slots.items():
            if isinstance(booking, dict):
                user_id = booking.get("id")
                first_name = booking.get("first_name", "Користувач")
                username = booking.get("username")
            else:
                user_id = booking
                first_name = "Користувач"
                username = None

            if user_id not in user_names:
                if username:
                    user_names[user_id] = f"{first_name} (@{username})"
                else:
                    user_names[user_id] = first_name

            user_display = user_names[user_id]
            message_lines.append(f"• {time_str} — {user_display}")

    final_message = "\n".join(message_lines)
    await update.message.reply_text(final_message or "Наразі немає активних бронювань.")


async def user_bookings_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != context.bot_data.get("ADMIN_ID") and user_id != update.effective_chat.id:
        await update.message.reply_text("⛔️ У вас немає прав для цієї команди.")
        return

    data = load_data()
    users = {}

    for date, times in data.items():
        for time, booking in times.items():
            if isinstance(booking, dict):
                uid = booking.get("id")
                if uid not in users:
                    users[uid] = {
                        "first_name": booking.get("first_name", "Користувач"),
                        "username": booking.get("username")
                    }

    keyboard = []
    for uid, info in users.items():
        name = info["first_name"]
        if info["username"]:
            name += f" (@{info['username']})"
        keyboard.append([InlineKeyboardButton(name, callback_data=f"user_bookings_{uid}")])

    if keyboard:
        await update.message.reply_text("Оберіть користувача:", reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        await update.message.reply_text("Немає активних бронювань.")

async def show_all_user_bookings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not query:
        return  # Можна ще надіслати повідомлення про помилку адміну

    await query.answer()

    from config import ADMIN_CHAT_ID
    user_id = update.effective_user.id

    if user_id != ADMIN_CHAT_ID:
        return

    uid = int(query.data.split("_")[-1])
    data = load_data()

    bookings = []
    for date, times in data.items():
        for time, booking in times.items():
            if isinstance(booking, dict) and booking.get("id") == uid:
                bookings.append(f"{date} — {time}")

    text = "\n".join(bookings) if bookings else "Немає активних бронювань."
    await query.edit_message_text(f"Бронювання користувача:\n{text}")
